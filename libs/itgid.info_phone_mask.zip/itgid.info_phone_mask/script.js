const progressLine = document.querySelector('.progress-line');
const phoneMask = document.getElementById('phone-mask');

IMask(
    phoneMask,
    {
      mask: '+{38} ({\\000) 000-00-00'
    }
  )

  document.getElementById('phone-mask').oninput = function (){
    console.log(this.value.length);

    const w = this.offsetWidth;
    progressLine.style.width = ((w/19) * this.value.length) + 'px';
    progressLine.style.backgroundColor = `rgb(${(255 - (255/19)* this.value.length)},137,0)`
  }